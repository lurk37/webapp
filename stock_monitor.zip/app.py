from flask import Flask, render_template, request
import pandas as pd
import requests
from bs4 import BeautifulSoup
import os
from glob import glob

app = Flask(__name__)

# CSV 파일 읽기 부분 수정
def get_latest_csv():
    csv_files = glob('./sise_csv/*.csv')
    if not csv_files:
        raise FileNotFoundError('sise_csv 폴더에 CSV 파일이 없습니다.')
    latest_file = max(csv_files, key=os.path.getctime)
    
    # 파일명에서 날짜와 시간 추출 (예: upper_limit_stocks_20241230_215134.csv)
    try:
        date_str = latest_file.split('_')[-2]  # 20241230
        time_str = latest_file.split('_')[-1].replace('.csv', '')  # 215134
        
        formatted_date = f"{date_str[:4]}년 {date_str[4:6]}월 {date_str[6:]}일"
        formatted_time = f"{time_str[:2]}:{time_str[2:4]}:{time_str[4:]}"
        trading_date = f"{formatted_date} {formatted_time}"
    except:
        trading_date = "날짜 형식 변환 실패"
    
    return latest_file, trading_date

# 전역 변수 df 초기화 부분 수정
csv_path, trading_date = get_latest_csv()
df = pd.read_csv(csv_path, dtype={'종목코드': str})

# 기업 요약과 관련 기사를 수집하는 함수
def get_company_info_and_news(종목코드, 종목명):
    # 네이버 금융에서 기업 정보 페이지 URL
    url = f"https://finance.naver.com/item/main.naver?code={종목코드}"
    
    # 요청 및 HTML 파싱
    response = requests.get(url)
    soup = BeautifulSoup(response.text, 'html.parser')
    
    # 기업 요약 정보 추출
    try:
        summary = soup.find('div', {'class': 'summary_info'}).get_text(strip=True)
    except AttributeError:
        summary = "기업 요약 정보를 찾을 수 없습니다."
    
    # 관련 기사 추출 (예: 네이버 뉴스)
    news_url = f"https://search.naver.com/search.naver?where=news&query={종목명}"
    news_response = requests.get(news_url)
    news_soup = BeautifulSoup(news_response.text, 'html.parser')
    
    news_list = []
    for news_item in news_soup.find_all('a', {'class': 'news_tit'}, limit=5):  # 상위 5개 기사만 추출
        news_title = news_item.get_text(strip=True)
        news_link = news_item['href']
        news_list.append((news_title, news_link))
    
    return summary, news_list

def get_all_trading_dates():
    csv_files = glob('./sise_csv/*.csv')
    if not csv_files:
        raise FileNotFoundError('sise_csv 폴더에 CSV 파일이 없습니다.')
    
    dates = []
    for file in csv_files:
        try:
            date_str = file.split('_')[-2]  # 20241230
            time_str = file.split('_')[-1].replace('.csv', '')  # 215134
            
            formatted_date = f"{date_str[:4]}년 {date_str[4:6]}월 {date_str[6:]}일 {time_str[:2]}:{time_str[2:4]}:{time_str[4:]}"
            dates.append({
                'display': formatted_date,
                'filename': file,
                'timestamp': f"{date_str}_{time_str}"
            })
        except:
            continue
    
    # 날짜 기준 내림차순 정렬
    dates.sort(key=lambda x: x['timestamp'], reverse=True)
    return dates

@app.route('/')
def index():
    # 모든 거래일자 가져오기
    trading_dates = get_all_trading_dates()
    
    # 선택된 날짜 가져오기 (기본값은 가장 최근 날짜)
    selected_date = request.args.get('date')
    if selected_date:
        csv_path = next((date['filename'] for date in trading_dates if date['timestamp'] == selected_date), trading_dates[0]['filename'])
        trading_date = next((date['display'] for date in trading_dates if date['timestamp'] == selected_date), trading_dates[0]['display'])
    else:
        csv_path = trading_dates[0]['filename']
        trading_date = trading_dates[0]['display']
    
    # CSV 파일 읽기
    global df
    df = pd.read_csv(csv_path, dtype={'종목코드': str})
    
    # '종목명' 열이 문자열 타입인지 확인하고, 아닌 경우 문자열로 변환
    df['종목명'] = df['종목명'].astype(str)

    # 검색어 가져오기
    search_query = request.args.get('search', '').strip()
    
    # 검색어가 있는 경우 필터링
    if search_query:
        filtered_df = df[df['종목명'].str.contains(search_query, case=False)]
    else:
        filtered_df = df
    
    # 필요한 열만 선택하여 결과를 준비합니다.
    results = []

    # 각 종목에 대해 정보 수집
    for index, row in filtered_df.iterrows():
        종목코드 = str(row['종목코드']).zfill(6)  # 6자리 문자열로 변환
        종목명 = row['종목명']
        
         # 기업 요약과 관련 기사를 수집하는 함수 호출
        summary, news_list = get_company_info_and_news(종목코드, 종목명)
        
        # 결과 저장
        results.append({
            '종목명': 종목명,
            '종목코드': 종목코드,
            '현재가': row['현재가'],
            '거래량': row['거래량'],
            '시가': row['시가'],
            '고가': row['고가'],
            '저가': row['저가'],
            'PER': row['PER'],
            '기업요약': summary,
            '관련기사': news_list
        })

    # 템플릿에 전달할 데이터프레임을 HTML로 변환
    df_html = df.to_html(classes='data', index=False)

    # 결과를 HTML 템플릿에 전달
    return render_template(
        'index.html',
        results=results,
        search_query=search_query,
        trading_date=trading_date,
        trading_dates=trading_dates,
        selected_date=selected_date,
        df_html=df_html
    )

if __name__ == '__main__':
    app.run(debug=True)